#include <cstdio>
#include <windows.h>
#include <cstdlib>
#include <conio.h>
#include <iostream>
#include <cstring>
using namespace std;
constexpr int N=25;
typedef long long LL;
LL fx[4][2]={{1,1},{1,0},{0,1},{1,-1}};
LL Q,GG;
string C[20]={"��","��","��","�T","�U","�X","�^","�[","�a","?"};//��
void color_fsg(LL a){//��ɫ����
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),a);
}
void gotoxy_fsg(LL x,LL y){
	COORD pos;
	pos.X=2*x;
	pos.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}
struct Gomoku{
	LL m[50][50],nx,ny;
	void reset_fsg()
	{
		system("cls");
		memset(m,-1,sizeof(m));
		color_fsg(7);
		for (LL i=1; i<=N; i++){
			gotoxy_fsg(0,i);cout<<C[4]; gotoxy_fsg(N+1,i);cout<<C[4];
			gotoxy_fsg(i,0);cout<<C[3]; gotoxy_fsg(i,N+1);cout<<C[3];
		}
		gotoxy_fsg(0,0);cout<<C[5]; gotoxy_fsg(0,N+1);cout<<C[6];
		gotoxy_fsg(N+1,0);cout<<C[7]; gotoxy_fsg(N+1,N+1);cout<<C[8];
		color_fsg(3);
		for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++)
			{
				gotoxy_fsg(i,j); cout<<C[2];
			}
		}
		nx=ny=N/2+1; gotoxy_fsg(nx,ny);
	}
	void _drop_fsg(LL x,LL i,LL j)
	{
		m[i][j]=x;
		gotoxy_fsg(i,j);
		color_fsg(15); cout<<C[x];
	}
	LL check(){
		for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++)
			{
				for (LL Fx=0,tmp,lst,xx,yy; Fx<4; Fx++) 
					if(m[i][j]!=-1){
						xx=i,yy=j,tmp=0,lst=m[i][j];
						for (LL k=1; k<=5; k++){
							if (xx>N || yy>N) break;
							if (m[xx][yy]==(lst^1)){break;}
							if (m[xx][yy]==lst) tmp++;
						xx+=fx[Fx][0],yy+=fx[Fx][1];
						}
					if (tmp==5){
						return lst;
					}
				}
			}
		
		}
		return -1;
	}
	LL arnd(LL x,LL y){
		LL cnt=0;
		for (LL i=x-1; i<=x+1; i++) if (i>0 && i<=N)
		for (LL j=y-1; j<=y+1; j++) if (j>0 && j<=N)
		if (m[i][j]>-1) cnt++;
		return cnt;
	}
	void get_val_fsg(LL x,LL y,LL &val){
		val=0;
		for(int i=1;i<=N;i++)
		{
			for(int j=1;j<=N;j++)
			{
				for (LL Fx=0,tmp,tk,xx,yy; Fx<4; Fx++)
				{
					xx=i,yy=j,tmp=tk=0;
					for (LL k=1; k<=5; k++)
					{
						if (xx>N || yy>N){tmp=0; break;}
						if (m[xx][yy]==(x^1)){tmp=0; break;}
						if (m[xx][yy]==x) tmp++,tk+=(1<<(k-1));
						xx+=fx[Fx][0],yy+=fx[Fx][1];
					}
					switch(tmp){
						case 5:
							val+=8000000000; break;
						case 4:
							val+=1000+350*y; break;
						case 3:
							val+=(tk==14)?(300+600*y):(300+200*y); break;
						case 2:
							val+=3+2*y; break;
						case 1:
							val+=1+y; break;
					}
				}
			}
		}
	}
	void AI_fsg(LL x){
		LL best,brnd,bi,bj,v1,v2,kkk;
		best=-2147483647;
		brnd=-2147483647;
		for(int i=1;i<=N;i++)
		{
			for(int j=1;j<=N;j++)
			{
				if (m[i][j]==-1)
				{
					m[i][j]=x;
					get_val_fsg(x,10,v1); //gotoxy_fsg(N+5,N/2);printf("%d ",v1);
					get_val_fsg(x^1,80,v2); //gotoxy_fsg(N+5,N/2+1);printf("%d ",v2);
					if (v1-v2>best) bi=i,bj=j,best=v1-v2;
					if (v1-v2==best)
					if ((kkk=arnd(i,j))>brnd)
						brnd=kkk,bi=i,bj=j;
					m[i][j]=-1;
				}
			}
		} 
		_drop_fsg(x,bi,bj);
	}
	void HM_fsg(LL x){
		char ch=getch();
		for (;;ch=getch())
		{
			if (ch=='w') {if (ny>1) ny--;}
			else if (ch=='s') {if (ny<N) ny++;}
			else if (ch=='a') {if (nx>1) nx--;}
			else if (ch=='d') {if (nx<N)nx++;}
			else if (m[nx][ny]==-1){_drop_fsg(x,nx,ny); return;}
			gotoxy_fsg(nx,ny);
		}
	}
} A;
int main()
{
	for (;;)
	{
		A.reset_fsg();
		for (GG=-1;;)
		{
			gotoxy_fsg(A.nx,A.ny);
			A.HM_fsg(0); GG=A.check(); if (GG>-1) break;
			A.AI_fsg(1); GG=A.check(); if (GG>-1) break;
		}
		gotoxy_fsg(5,N+3);
		if (GG==0) printf("AI_1 win!");
		if (GG==1) printf("AI_2 wins!");
		while (kbhit()) getch();
		Sleep(500);
		gotoxy_fsg(5,N+3);
		printf("Press anything to continue.");
		return 0;
	}
}
